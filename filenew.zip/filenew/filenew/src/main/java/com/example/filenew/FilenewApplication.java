package com.example.filenew;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilenewApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilenewApplication.class, args);
	}

}
